library(testthat)
library(ggseas)

test_check("ggseas")
